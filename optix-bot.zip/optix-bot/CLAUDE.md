# OptiX Bot — Automated Optical Computing Research Posts for X

## Project Overview

Automated system that scrapes optical computing papers/news, generates concise research thread posts via Claude API, and posts to X (Twitter). Targets photonics researchers and EE/physics grad students. All content in English.

**Mode: Semi-automatic** — generates drafts → sends to Telegram for human approval → posts on approval.

## Architecture

```
[Scraper] → [Scorer/Filter] → [Claude API Generator] → [Telegram Preview] → [X Poster]
                                                              ↑
                                                        Human approves
```

## Tech Stack

- **Language**: Python 3.11+
- **LLM**: Claude API (claude-sonnet-4-20250514)
- **Posting**: X API v2 (tweepy or httpx)
- **Approval channel**: Telegram Bot API
- **Deployment**: Railway (cron jobs)
- **Storage**: SQLite (posted history, pending queue)

## Project Structure

```
optix-bot/
├── CLAUDE.md
├── requirements.txt
├── .env.example
├── railway.toml
├── src/
│   ├── __init__.py
│   ├── config.py          # All settings, keywords, API keys
│   ├── scraper.py          # arXiv + RSS + news collection
│   ├── scorer.py           # Keyword scoring & filtering
│   ├── generator.py        # Claude API thread generation
│   ├── telegram_bot.py     # Preview + approve/reject interface
│   ├── poster.py           # X API thread posting
│   ├── scheduler.py        # Main orchestrator (cron entry point)
│   └── db.py               # SQLite operations
├── data/
│   └── optix.db            # SQLite database (auto-created)
└── tests/
    ├── test_scraper.py
    ├── test_scorer.py
    └── test_generator.py
```

## Module Specifications

### 1. scraper.py

**arXiv**:
- Use arXiv API (HTTP GET to `http://export.arxiv.org/api/query`)
- Categories: `physics.optics`, `cs.ET`, `eess.SP`, `quant-ph`, `cs.AR`
- Query: search within these categories, sorted by `submittedDate`, last 24-48 hours
- Rate limit: minimum 3 seconds between requests
- Parse: title, authors, abstract, published date, arxiv URL, categories

**RSS Feeds (journals)**:
- Optica Publishing: https://opg.optica.org/rss/
- Nature Photonics: https://www.nature.com/nphoton.rss
- Light: Science & Applications: https://www.nature.com/lsa.rss
- ACS Photonics RSS
- APL Photonics RSS
- Laser & Photonics Reviews RSS
- Use `feedparser` library. Parse title, abstract/summary, link, published date.

**Industry News**:
- IEEE Spectrum photonics: RSS
- PhotonicsMedia: RSS
- Company blogs (Lightmatter, Celestial AI, Xanadu, Luminous Computing): RSS where available
- These may need `requests` + `BeautifulSoup` fallback if RSS unavailable.

**Output**: List of `Paper` objects with unified schema:
```python
@dataclass
class Paper:
    title: str
    authors: str
    abstract: str
    url: str
    source: str          # "arxiv", "nature_photonics", "ieee_spectrum", etc.
    published_date: str   # ISO format
    doi: str | None
    categories: list[str]
```

### 2. scorer.py

Score each paper by keyword match relevance.

**Core keywords** (+3 each): optical computing, photonic computing, photonic neural network, optical neural network, silicon photonics, photonic integrated circuit, optical interconnect, photonic accelerator, optical matrix multiplication, photonic tensor core, mach-zehnder interferometer, diffractive optical network, diffractive neural network, D2NN, neuromorphic photonics, all-optical computing, electro-optic computing, photonic reservoir computing, optical transformer, photonic transformer, optical AI accelerator

**Secondary keywords** (+1 each): metasurface computing, programmable photonics, phase-change material photonic, photonic FPGA, wavelength division multiplexing computing, free-space optical computing, microring resonator, optical nonlinearity neural, optical inference, photonic crossbar, optical convolution, integrated photonics machine learning, optical signal processing, coherent optical computing, photonic weight bank

**Source bonus**:
- Nature Photonics, Light Sci & App, Optica: +5
- ACS Photonics, APL Photonics, Photonics Research: +3
- IEEE Spectrum, PhotonicsMedia: +2
- arXiv (no journal): +0

**Notable affiliation bonus** (+2): MIT, Stanford, Caltech, KAIST, SNU, ETH Zurich, University of Oxford, Lightmatter, Celestial AI, Xanadu, iPronics

**Threshold**: score >= 6 to qualify. Take top 3 per run maximum. Skip already-posted (check DB by URL/DOI).

### 3. generator.py

Call Claude API to generate an X thread from a paper.

**System prompt**:
```
You are a research communicator for optical computing on X (Twitter).
Target audience: photonics researchers and EE/physics grad students.
Language: English.

Generate a 4-tweet thread:
- Tweet 1 (Hook): Why this matters. One compelling line about the breakthrough. Start with a relevant emoji.
- Tweet 2 (Key Findings): Concrete results with numbers from the abstract (accuracy, speed, power, footprint). Do NOT invent numbers.
- Tweet 3 (Significance): How it compares to prior work. What direction it pushes the field.
- Tweet 4 (Source): Paper link + 3-5 hashtags.

Rules:
- Each tweet MUST be under 280 characters.
- Keep technical terms (MZI, PIC, ONN, TOPS, SiPh, etc.) — the audience knows them.
- Tone: knowledgeable, concise, no hype. Think "lab group chat sharing a cool paper."
- NEVER hallucinate numbers. Only cite figures explicitly stated in the abstract.
- Output as JSON: {"tweets": [{"index": 1, "text": "..."}, ...]}
- No markdown, no backticks in tweet text.
```

**User prompt template**:
```
Generate an X thread for this paper:

Title: {title}
Authors: {authors}
Abstract: {abstract}
Source: {source}
URL: {url}

Return JSON only. Each tweet under 280 characters.
```

**Post-processing**:
- Validate JSON parse
- Validate each tweet <= 280 chars. If over, call Claude again with "Shorten tweet {n} to under 280 characters."
- Validate no fabricated numbers (optional: cross-check numbers against abstract)

### 4. telegram_bot.py

**Semi-auto approval flow**:

1. When a thread is generated, send it to a Telegram chat as a formatted preview:
```
📄 NEW POST DRAFT
Source: Nature Photonics
Score: 12

🧵 Thread Preview:
[1/4] 🔬 ...
[2/4] 📊 ...
[3/4] 💡 ...
[4/4] 📎 ...

Total chars: 234 / 247 / 198 / 156
```

2. Inline keyboard buttons: `[✅ Approve]  [✏️ Edit]  [❌ Reject]`

3. On Approve → call poster.py → post thread → send confirmation
4. On Reject → mark as rejected in DB, move on
5. On Edit → reply with revised text → update and re-preview

**Implementation**: Use `python-telegram-bot` library (async). Can run as webhook on Railway or long-polling.

### 5. poster.py

**X API v2** via `tweepy` (v2 client):

```python
def post_thread(tweets: list[str], client: tweepy.Client) -> list[str]:
    """Post a thread. Returns list of tweet IDs."""
    tweet_ids = []
    previous_id = None
    for tweet_text in tweets:
        params = {"text": tweet_text}
        if previous_id:
            params["in_reply_to_tweet_id"] = previous_id
        response = client.create_tweet(**params)
        tweet_id = response.data["id"]
        tweet_ids.append(tweet_id)
        previous_id = tweet_id
        time.sleep(1)
    return tweet_ids
```

- Free tier: 1,500 tweets/month write limit → ~3 threads/day * 4 tweets * 30 days = 360/month → safe
- After posting, save tweet IDs + paper info to DB

### 6. db.py

SQLite with tables:
- `papers`: all scraped papers (url, title, source, score, status, scraped_at)
- `posts`: posted threads (paper_url, tweet_ids, posted_at, approved_by)
- `queue`: pending approval (paper_url, generated_thread_json, created_at, status)

Status flow: `scraped → scored → generated → pending_approval → approved/rejected → posted`

### 7. scheduler.py

Main entry point for Railway cron.

```python
def run():
    # 1. Scrape all sources
    papers = scrape_all()
    
    # 2. Score and filter
    candidates = score_and_filter(papers)  # top 3, score >= 6
    
    # 3. Generate threads for candidates
    for paper in candidates:
        thread = generate_thread(paper)
        
        # 4. Send to Telegram for approval
        send_to_telegram(paper, thread)
        
        # 5. Save to queue (status: pending_approval)
        save_to_queue(paper, thread)
    
    # Posting happens via Telegram bot callback, not here.
```

**Railway cron schedule**:
- Scrape + generate: twice daily (e.g., 08:00, 20:00 UTC)
- Telegram bot: runs continuously (separate Railway service or same process with async)

## Environment Variables (.env.example)

```
CLAUDE_API_KEY=sk-ant-...
X_API_KEY=
X_API_SECRET=
X_ACCESS_TOKEN=
X_ACCESS_SECRET=
X_BEARER_TOKEN=
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=
```

## Key Dependencies (requirements.txt)

```
anthropic>=0.40.0
tweepy>=4.14.0
python-telegram-bot>=21.0
feedparser>=6.0.0
requests>=2.31.0
beautifulsoup4>=4.12.0
python-dotenv>=1.0.0
apscheduler>=3.10.0
```

## Build Order (for Claude Code)

Phase 1: `config.py` → `db.py` → `scraper.py` (arXiv only first) → test scraper
Phase 2: `scorer.py` → test with scraped data → verify filtering works
Phase 3: `generator.py` → test Claude API call → validate output format
Phase 4: `telegram_bot.py` → test preview + approve flow
Phase 5: `poster.py` → test single tweet → test thread posting
Phase 6: `scheduler.py` → wire everything → test full pipeline locally
Phase 7: Railway deployment → cron setup → monitor

## Important Notes

- arXiv rate limit: 3s between requests minimum. Be respectful.
- X Free tier: 1,500 tweets/month. Monitor usage.
- Claude API: Use Sonnet for cost efficiency. ~$0.003 per thread generation.
- All content in English. International audience.
- Semi-auto mode: NOTHING posts without Telegram approval.
- Store all papers even if not posted (for future analysis / weekly digest features).
