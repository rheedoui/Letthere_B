"""
OptiX Bot — Configuration
Automated optical computing research posts for X (Twitter)
"""

import os
from dotenv import load_dotenv

load_dotenv()

# ── API Keys (set in .env or Railway env vars) ──────────────────────
CLAUDE_API_KEY = os.getenv("CLAUDE_API_KEY", "")
X_API_KEY = os.getenv("X_API_KEY", "")
X_API_SECRET = os.getenv("X_API_SECRET", "")
X_ACCESS_TOKEN = os.getenv("X_ACCESS_TOKEN", "")
X_ACCESS_SECRET = os.getenv("X_ACCESS_SECRET", "")
X_BEARER_TOKEN = os.getenv("X_BEARER_TOKEN", "")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

# ── Claude API ──────────────────────────────────────────────────────
CLAUDE_MODEL = "claude-sonnet-4-20250514"
CLAUDE_MAX_TOKENS = 1500

# ── Scheduling ──────────────────────────────────────────────────────
MAX_POSTS_PER_DAY = 3
SCORE_THRESHOLD = 6  # minimum score to qualify for posting

# ── arXiv Categories ────────────────────────────────────────────────
ARXIV_CATEGORIES = [
    "physics.optics",
    "cs.ET",        # Emerging Technologies
    "eess.SP",      # Signal Processing
    "quant-ph",     # Photonic quantum computing
    "cs.AR",        # Hardware Architecture (optical accelerators)
]

# ── Core Keywords (score +3 each) ──────────────────────────────────
CORE_KEYWORDS = [
    "optical computing",
    "photonic computing",
    "photonic neural network",
    "optical neural network",
    "silicon photonics",
    "photonic integrated circuit",
    "optical interconnect",
    "photonic accelerator",
    "optical matrix multiplication",
    "photonic tensor core",
    "mach-zehnder interferometer",
    "diffractive optical network",
    "diffractive neural network",
    "d2nn",
    "neuromorphic photonics",
    "all-optical computing",
    "electro-optic computing",
    "photonic reservoir computing",
    "optical transformer",
    "photonic transformer",
    "optical AI accelerator",
]

# ── Secondary Keywords (score +1 each) ─────────────────────────────
SECONDARY_KEYWORDS = [
    "metasurface computing",
    "programmable photonics",
    "phase-change material photonic",
    "photonic FPGA",
    "wavelength division multiplexing computing",
    "free-space optical computing",
    "microring resonator",
    "optical nonlinearity neural",
    "optical inference",
    "photonic crossbar",
    "optical convolution",
    "integrated photonics machine learning",
    "optical signal processing",
    "coherent optical computing",
    "photonic weight bank",
]